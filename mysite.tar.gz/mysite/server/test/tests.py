from django.contrib.auth.hashers import make_password
from django.test import Client, TestCase
import os, sys, django, base64, json

sys.path.append('/home/yakir/Desktop/work/mysite')
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'mysite.settings')
django.setup()

from server.models import Admin, Teacher, Student, Course, StudentCourseInfo
from django.contrib.auth.models import Group


class ServerTest(TestCase):
    def setUp(self):
        self.default_password = '123123'

        # ADMIN
        self.admin = Admin.objects.create_user(username="AdminUser", password=self.default_password)
        admins_group = Group.objects.get(name='admins')
        self.admin.groups.add(admins_group)

        # TEACHER
        self.teacher = Teacher.objects.create_user(username="Aviyam", password=self.default_password)
        teachers_group = Group.objects.get(name='teachers')
        self.teacher.groups.add(teachers_group)

        # STUDENT
        self.student = Student.objects.create_user(username="Elinor", password=self.default_password)
        students_group = Group.objects.get(name='students')
        self.student.groups.add(students_group)

        # CLASS
        self.course = Course.objects.create(
            name="Mathematics",
            description="Mathematics...",
            teacher=self.teacher,
            year=2017
        )

        # STUDENT COURSE INFO
        self.student_course_info = StudentCourseInfo.objects.create(
            student=self.student,
            course=self.course,
            grade=70,
        )

        self.client = Client()

    def runTest(self):
        self.login_check_good_credentials()
        self.login_check_bad_credentials()
        self.teacher_check_good_permissions()
        self.teacher_check_bad_permissions()
        self.student_check_good_permissions()
        self.student_check_bad_permissions()
        self.admin_check_all_permissions()

    def login_check_good_credentials(self):
        login = self.client.login(username=self.teacher.username, password=self.default_password)
        self.assertTrue(login, "Not successed login with good credentials.")

    def login_check_bad_credentials(self):
        login = self.client.login(username=self.teacher.username, password=self.default_password + '2')
        self.assertFalse(login, "Successed login with bad credentials.")    

    def teacher_check_good_permissions(self):
        credentials = base64.b64encode('{}:{}'.format(self.teacher.username, self.default_password))
        self.client.defaults['HTTP_AUTHORIZATION'] = 'Basic ' + credentials
        self.client.defaults['content_type'] = 'application/json'

        response = self.client.get(path='/server/api/teacher/').status_code
        self.assertTrue(response == 200, 'Teacher can\'t view his details.')

        response = self.client.get(path='/server/api/course/').status_code
        self.assertTrue(response == 200, 'Teacher can\'t view his courses.')

        response = self.client.get(path='/server/api/student_course_info/').status_code
        self.assertTrue(response == 200, 'Teacher can\'t view his students info.')
        perm = self.teacher.get_all_permissions()
        student_grade = self.student_course_info.grade
        numb = 10
        response = self.client.patch(
            path='/server/api/student_course_info/?id={}'.format(self.student_course_info.id),
            data=
            json.dumps(
                {
                    "objects": [
                        {
                            'id': self.student_course_info.id,
                            'grade': (student_grade - numb),
                        }
                    ]
                }
            ),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 202, 'Teacher can\'t update student grades.')

        # UPDATE STUDENT FROM DATABASE
        self.student_course_info = StudentCourseInfo.objects.filter(id=self.student_course_info.id)[0]

        # CHECK UPDATING FIELD
        self.assertTrue(((student_grade - numb) == self.student_course_info.grade), 'Updating invalid.')  # CHECK GRADE

    def teacher_check_bad_permissions(self):
        credentials = base64.b64encode('{}:{}'.format(self.teacher.username, self.default_password))
        self.client = Client()
        self.client.defaults['HTTP_AUTHORIZATION'] = 'Basic ' + credentials
        self.client.defaults['content_type'] = 'application/json'

        # -----------  TEACHER SECTION -------------

        # CREATE
        response = self.client.post(
            path='/server/api/teacher/',
            data=
            json.dumps(
                {
                    "objects": [
                        {
                            'username': 'teacher_user',
                            'password': '123123'
                        }
                    ]
                }
            ),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 401, 'Teacher can create teacher user.')

        # UPDATE
        response = self.client.patch(
            path='/server/api/teacher/?id={}'.format(self.teacher.id),
            data=
            json.dumps(
                {
                    "objects": [
                        {
                            'id': self.teacher.id,
                            'username': self.teacher.username + "abc"
                        }
                    ]
                }
            ),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 401, 'Teacher can update teacher details.')

        # DELETE
        response = self.client.delete(
            path='/server/api/teacher/?id={}'.format(self.teacher.id),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 401, 'Teacher can delete teacher user.')

        # -----------  ADMIN SECTION -------------
        # VIEW
        response = self.client.get(path='/server/api/admin/?id=1').status_code
        self.assertTrue(response == 401, 'Teacher can view admin details.')

        # CREATE
        response = self.client.post(
            path='/server/api/admin/',
            data=
            json.dumps(
                {
                    "objects": [
                        {
                            'username': 'create_admin',
                            'password': '123123',
                        }
                    ]
                }
            ),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 401, 'Teacher can create admin user.')

        # UPDATE
        response = self.client.patch(
            path='/server/api/admin/?id={}'.format(self.admin.id),
            data=
            json.dumps(
                {
                    "objects": [
                        {
                            'id': self.admin.id,
                            'email': (self.admin.email + "abc"),
                        }
                    ]
                }
            ),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 401, 'Teacher can update admin details.')

        # DELETE
        response = self.client.delete(
            path='/server/api/admin/?id={}'.format(self.admin.id),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 401, 'Teacher can delete admin user.')


        # -----------  STUDENT SECTION -------------
        # VIEW
        response = self.client.get(path='/server/api/student/?id=1').status_code
        self.assertTrue(response == 401, 'Teacher can view student details.')

        # CREATE
        response = self.client.post(
            path='/server/api/student/',
            data=
            json.dumps(
                {
                    "objects": [
                        {
                            'username': 'create_student',
                            'password': '123123',
                        }
                    ]
                }
            ),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 401, 'Teacher can create student user.')

        # UPDATE
        response = self.client.patch(
            path='/server/api/student/?id={}'.format(self.admin.id),
            data=
            json.dumps(
                {
                    "objects": [
                        {
                            'id': self.student.id,
                            'email': (self.student.email + "abc"),
                        }
                    ]
                }
            ),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 401, 'Teacher can update student details.')

        # DELETE
        response = self.client.delete(
            path='/server/api/admin/?id={}'.format(self.admin.id),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 401, 'Teacher can delete student user.')

        # -----------  COURSE SECTION -------------
        # CREATE
        response = self.client.post(
            path='/server/api/course/',
            data=
            json.dumps(
                {
                    "objects": [
                        {
                            'name': 'coumputer_science',
                            'description': "Computer...",
                            'year': 2017
                        }
                    ]
                }
            ),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 401, 'Teacher can create course.')

        # UPDATE
        response = self.client.patch(
            path='/server/api/course/?id={}'.format(self.course.id),
            data=
            json.dumps(
                {
                    "objects": [
                        {
                            'id': self.course.id,
                            'name': (self.course.name + "abc"),
                        }
                    ]
                }
            ),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 401, 'Teacher can update course details.')

        # DELETE
        response = self.client.delete(
            path='/server/api/course/?id={}'.format(self.course.id),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 401, 'Teacher can delete course.')

        # -----------  STUDENT COURSE SECTION SECTION -------------
        # CREATE
        response = self.client.post(
            path='/server/api/student_course_info/',
            data=
            json.dumps(
                {
                    "objects": [
                        {
                            'grade': 100
                        }
                    ]
                }
            ),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 401, 'Teacher can create student course info.')

        # DELETE
        response = self.client.delete(
            path='/server/api/student_course_info/?id={}'.format(self.student_course_info.id),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 401, 'Teacher can delete course.')

    def student_check_good_permissions(self):
        credentials = base64.b64encode('{}:{}'.format(self.student.username, self.default_password))
        self.client.defaults['HTTP_AUTHORIZATION'] = 'Basic ' + credentials
        self.client.defaults['content_type'] = 'application/json'

        response = self.client.get(path='/server/api/student/').status_code
        self.assertTrue(response == 200, 'Student can\'t view his user details.')

        response = self.client.get(path='/server/api/course/').status_code
        self.assertTrue(response == 200, 'Student can\'t view his courses.')

        response = self.client.get(path='/server/api/student_course_info/').status_code
        self.assertTrue(response == 200, 'Student can\'t view his courses info.')

        response = self.client.post(
            path='/server/api/student_course_info/',
            data=
            json.dumps(
                {
                    "objects": [
                        {
                            'student': self.student.id,
                            'course': self.course.id,
                            'grade': 'Not set'
                        }
                    ]
                }
            ),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 201, 'Student can\'t enroll courses.')

        # UPDATE STUDENT FROM DATABASE
        student_course = StudentCourseInfo.objects.filter(
            student=self.student).filter(
            course=self.course
        )[0]

        # CREATE CHECKING
        self.assertTrue((student_course.student == self.student and student_course.course == self.course), 'Updating invalid.')  # CHECK GRADE

    def student_check_bad_permissions(self):
        credentials = base64.b64encode('{}:{}'.format(self.student.username, self.default_password))
        self.client = Client()
        self.client.defaults['HTTP_AUTHORIZATION'] = 'Basic ' + credentials
        self.client.defaults['content_type'] = 'application/json'

        # -----------  TEACHER SECTION -------------

        # CREATE
        response = self.client.post(
            path='/server/api/teacher/',
            data=
            json.dumps(
                {
                    "objects": [
                        {
                            'username': 'teacher_user',
                            'password': '123123'
                        }
                    ]
                }
            ),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 401, 'Student can create teacher user.')

        # UPDATE
        response = self.client.patch(
            path='/server/api/student/?id={}'.format(self.student.id),
            data=
            json.dumps(
                {
                    "objects": [
                        {
                            'id': self.teacher.id,
                            'username': self.teacher.username + "abc"
                        }
                    ]
                }
            ),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 401, 'Student can update teacher details.')

        # DELETE
        response = self.client.delete(
            path='/server/api/student/?id={}'.format(self.student.id),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 401, 'Student can delete teacher user.')

        # -----------  ADMIN SECTION -------------
        # VIEW
        response = self.client.get(path='/server/api/admin/?id=1').status_code
        self.assertTrue(response == 401, 'Student can view admin details.')

        # CREATE
        response = self.client.post(
            path='/server/api/admin/',
            data=
            json.dumps(
                {
                    "objects": [
                        {
                            'username': 'create_admin',
                            'password': '123123',
                        }
                    ]
                }
            ),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 401, 'Student can create admin user.')

        # UPDATE
        response = self.client.patch(
            path='/server/api/admin/?id={}'.format(self.admin.id),
            data=
            json.dumps(
                {
                    "objects": [
                        {
                            'id': self.admin.id,
                            'email': (self.admin.email + "abc"),
                        }
                    ]
                }
            ),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 401, 'Student can update admin details.')

        # DELETE
        response = self.client.delete(
            path='/server/api/admin/?id={}'.format(self.admin.id),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 401, 'Student can delete admin user.')


        # -----------  STUDENT SECTION -------------
        # CREATE
        response = self.client.post(
            path='/server/api/student/',
            data=
            json.dumps(
                {
                    "objects": [
                        {
                            'username': 'create_student',
                            'password': '123123',
                        }
                    ]
                }
            ),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 401, 'Student can create student user.')

        # UPDATE
        response = self.client.patch(
            path='/server/api/student/?id={}'.format(self.student.id),
            data=
            json.dumps(
                {
                    "objects": [
                        {
                            'id': self.student.id,
                            'email': (self.student.email + "abc"),
                        }
                    ]
                }
            ),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 401, 'Student can update student details.')

        # DELETE
        response = self.client.delete(
            path='/server/api/student/?id={}'.format(self.student.id),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 401, 'Student can delete student user.')

        # -----------  COURSE SECTION -------------
        # CREATE
        response = self.client.post(
            path='/server/api/course/',
            data=
            json.dumps(
                {
                    "objects": [
                        {
                            'name': 'coumputer_science',
                            'description': "Computer...",
                            'year': 2017
                        }
                    ]
                }
            ),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 401, 'Student can create course.')

        # UPDATE
        response = self.client.patch(
            path='/server/api/course/?id={}'.format(self.course.id),
            data=
            json.dumps(
                {
                    "objects": [
                        {
                            'id': self.course.id,
                            'name': (self.course.name + "abc"),
                        }
                    ]
                }
            ),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 401, 'Student can update course details.')

        # DELETE
        response = self.client.delete(
            path='/server/api/course/?id={}'.format(self.course.id),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 401, 'Student can delete course.')

        # -----------  STUDENT COURSE SECTION SECTION -------------
        # CHANGE
        response = self.client.put(
            path='/server/api/student_course_info/?student={}&course={}'.format(self.student.id, self.course.id),
            data=
            json.dumps(
                {
                    "objects": [
                        {
                            'grade': 100
                        }
                    ]
                }
            ),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 401, 'Student can change student course info.')

        # DELETE
        response = self.client.delete(
            path='/server/api/student_course_info/?student={}&course={}'.format(self.student.id, self.course.id),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 401, 'Student can delete course info.')

    def admin_check_all_permissions(self):
        credentials = base64.b64encode('{}:{}'.format(self.admin.username, self.default_password))
        self.client = Client()
        self.client.defaults['HTTP_AUTHORIZATION'] = 'Basic ' + credentials
        self.client.defaults['content_type'] = 'application/json'

        # -----------  TEACHER SECTION -------------
        # VIEW
        response = self.client.get(path='/server/api/teacher/').status_code
        self.assertTrue(response == 200, 'Admin can\'t view his details.')

        # UPDATE
        response = self.client.patch(
            path='/server/api/teacher/?id={}'.format(self.student.id),
            data=
            json.dumps(
                {
                    "objects": [
                        {
                            'id': self.teacher.id,
                            'username': self.teacher.username + "abc"
                        }
                    ]
                }
            ),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 202, 'Admin can update teacher details.')

        # DELETE
        response = self.client.delete(
            path='/server/api/teacher/?id={}'.format(self.teacher.id),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 204, 'Admin can delete teacher user.')


        # -----------  STUDENT SECTION -------------
        # VIEW
        response = self.client.get(path='/server/api/student/').status_code
        self.assertTrue(response == 200, 'Admin can view student details.')

        # UPDATE
        response = self.client.patch(
            path='/server/api/student/?id={}'.format(self.student.id),
            data=
            json.dumps(
                {
                    "objects": [
                        {
                            'id': self.student.id,
                            'email': (self.student.email + "abc"),
                        }
                    ]
                }
            ),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 202, 'Admin can update student details.')

        # DELETE
        response = self.client.delete(
            path='/server/api/student/?id={}'.format(self.student.id),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 204, 'Admin can delete student user.')

        # -----------  COURSE SECTION -------------
        # VIEW
        response = self.client.get(path='/server/api/course/').status_code
        self.assertTrue(response == 200, 'Admin can view course details.')

        # CREATE
        response = self.client.post(
            path='/server/api/course/',
            data=
            json.dumps(
                {
                    "objects": [
                        {
                            'name': 'coumputer_science',
                            'description': "Computer...",
                            'year': 2017
                        }
                    ]
                }
            ),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 201, 'Admin can create course.')

        # UPDATE
        response = self.client.put(
            path='/server/api/course/?id={}'.format(self.course.id),
            data=
            json.dumps(
                {
                    "objects": [
                        {
                            'id': self.course.id,
                            'name': (self.course.name + "abc"),
                        }
                    ]
                }
            ),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 204, 'Admin can update course details.')

        # DELETE
        response = self.client.delete(
            path='/server/api/course/?id={}'.format(self.course.id),
            **self.client.defaults
        ).status_code
        self.assertTrue(response == 204, 'Admin can delete course.')

        # -----------  STUDENT COURSE SECTION SECTION -------------
        # VIEW
        response = self.client.get(path='/server/api/student_course_info/').status_code
        self.assertTrue(response == 200, 'Admin can view student course details.')

        # TEACHER
        self.teacher = Teacher.objects.create_user(username="Aviyam2", password=self.default_password)
        teachers_group = Group.objects.get(name='teachers')
        self.teacher.groups.add(teachers_group)

        # STUDENT
        self.student = Student.objects.create_user(username="Elinor2", password=self.default_password)
        students_group = Group.objects.get(name='students')
        self.student.groups.add(students_group)

        # CLASS
        self.course = Course.objects.create(
            name="Mathematics2",
            description="Mathematics...2",
            teacher=self.teacher,
            year=2017
        )

        # STUDENT COURSE INFO
        self.student_course_info = StudentCourseInfo.objects.create(
            student=self.student,
            course=self.course,
            grade=70,
        )