# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User


# Create your models here.

class Admin(User):
    pass


class Teacher(User):
    personal_page = models.URLField(null=True, blank=True)

    def __str__(self):
        return str(self.username)


class Student(User):
    pass

    def __str__(self):
        return str(self.username)


class Course(models.Model):
    name = models.CharField(max_length=200, null=True, blank=True)
    description = models.CharField(max_length=200, null=True, blank=True)
    teacher = models.ForeignKey(Teacher, related_name='course_set', null=True, blank=True)
    year = models.IntegerField(null=True, blank=True)
    students = models.ManyToManyField('server.Student', related_name='course_set', through='server.StudentCourseInfo')

    class Meta:
        unique_together = ('name', 'teacher', 'year',)
        default_permissions = ('add', 'change', 'delete', 'view')

    def __str__(self):
        return str(self.name)


class StudentCourseInfo(models.Model):
    student = models.ForeignKey(Student, related_name='studentcourseinfo_set', on_delete=models.CASCADE, null=True, blank=True)
    course = models.ForeignKey(Course, related_name='studentcourseinfo_set', on_delete=models.CASCADE, null=True, blank=True)
    grade = models.IntegerField(null=True, blank=True)

    def __str__(self):
        return str(self.grade)

    class Meta:
        auto_created = True
