from django.conf.urls import url, include
from tastypie.api import Api
from server.api.resources import UserResource, AdminResource, TeacherResource, StudentResource, CourseResource, StudentCourseInfoResource

app_name = 'server'


api = Api(api_name='api')
api.register(UserResource())
api.register(AdminResource())
api.register(TeacherResource())
api.register(StudentResource())
api.register(CourseResource())
api.register(StudentCourseInfoResource())

urlpatterns = [
    # ex: /server/
    url(r'^', include(api.urls)),
]
