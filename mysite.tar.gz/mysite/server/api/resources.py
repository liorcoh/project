from tastypie.resources import ModelResource, ALL_WITH_RELATIONS
from tastypie import fields, utils
from server.models import User, Admin, Teacher, Student, Course, StudentCourseInfo
from server.authorization import CustomDjangoAuthorization
from tastypie.authentication import BasicAuthentication


class UserResource(ModelResource):
    class Meta:
        queryset = User.objects.all()
        resource_name = 'user'
        fields = ['id', 'username', 'email']
        authentication = BasicAuthentication()
        authorization = CustomDjangoAuthorization()
        filtering = {
            'id': 'exact',
            'username': 'exact',
        }


class AdminResource(ModelResource):
    class Meta:
        queryset = Admin.objects.all()
        resource_name = 'admin'
        fields = ['id', 'username', 'email']
        authentication = BasicAuthentication()
        authorization = CustomDjangoAuthorization()
        filtering = {
            'id': 'exact',
            'username': 'exact',
        }


class TeacherResource(ModelResource):
    #course = fields.ToManyField('server.api.resources.CourseResource', 'course_set')

    class Meta:
        queryset = Teacher.objects.all()
        resource_name = 'teacher'
        fields = ['id', 'username', 'email', 'personal_page']
        authentication = BasicAuthentication()
        authorization = CustomDjangoAuthorization()
        filtering = {
            'id': 'exact',
            'username': 'exact',
        #    'course': 'exact',
        }


class StudentResource(ModelResource):
    class Meta:
        queryset = Student.objects.all()
        fields = ['id', 'username', 'email', 'student_id']
        resource_name = 'student'
        authentication = BasicAuthentication()
        authorization = CustomDjangoAuthorization()
        filtering = {
            'id': 'exact',
            'username': 'exact',
        }


class CourseResource(ModelResource):
    teacher = fields.ToOneField('server.api.resources.TeacherResource', 'teacher', null=True, blank=True, full=False)
    student = fields.ToManyField('server.api.resources.StudentResource', 'students', null=True, blank=True, full=False)

    class Meta:
        queryset = Course.objects.all()
        resource_name = 'course'
        fields = ['id', 'name', 'teacher', 'year']
        authentication = BasicAuthentication()
        authorization = CustomDjangoAuthorization()
        filtering = {
            'id': 'exact',
            'year': 'exact',
            'name': 'exact',
            'teacher': ALL_WITH_RELATIONS,
            'student': ALL_WITH_RELATIONS,
        }


class StudentCourseInfoResource(ModelResource):
    student = fields.ToOneField(StudentResource, 'student', null=True, blank=True)
    course = fields.ToOneField(CourseResource, 'course', null=True, blank=True)

    class Meta:
        queryset = StudentCourseInfo.objects.all()
        resource_name = 'student_course_info'
        fields = ['id', 'grade', 'student', 'student_class']
        authentication = BasicAuthentication()
        authorization = CustomDjangoAuthorization()
        filtering = {
            'id': 'exact',
            'grade': 'exact',
            'student': ALL_WITH_RELATIONS,
            'course': ALL_WITH_RELATIONS,
        }
