from tastypie.authorization import Authorization
from tastypie.exceptions import Unauthorized
from server.models import Course, Student


class CustomDjangoAuthorization(Authorization):
    def read_list(self, object_list, bundle):
        app_label = bundle.obj._meta.app_label
        model_name = bundle.obj._meta.model_name
        if bundle.request.user.has_perm('{}.view_{}'.format(app_label, model_name)):
            return object_list
        raise Unauthorized("You are not allowed to access that resource.")

    def read_detail(self, object_list, bundle):
        app_label = bundle.obj._meta.app_label
        model_name = bundle.obj._meta.model_name
        if bundle.request.user.has_perm('{}.view_{}'.format(app_label, model_name)):
            return True
        raise Unauthorized("You are not allowed to access that resource.")

    def create_list(self, object_list, bundle):
        app_label = bundle.obj._meta.app_label
        model_name = bundle.obj._meta.model_name
        if bundle.request.user.has_perm('{}.add_{}'.format(app_label, model_name)):
            if model_name == 'studentcourseinfo':
                bundle.obj.course = Course.objects.filter(id=bundle.data['objects'][0]['course'])[0]
                bundle.obj.student = Student.objects.filter(id=bundle.data['objects'][0]['student'])[0]
                bundle.obj.grade = 0
            return object_list
        raise Unauthorized("You are not allowed to access that resource.")

    def create_detail(self, object_list, bundle):
        app_label = bundle.obj._meta.app_label
        model_name = bundle.obj._meta.model_name
        if bundle.request.user.has_perm('{}.add_{}'.format(app_label, model_name)):
            if model_name == 'studentcourseinfo':
                bundle.obj.course = Course.objects.filter(id=bundle.data['objects'][0]['course'])[0]
                bundle.obj.student = Student.objects.filter(id=bundle.data['objects'][0]['student'])[0]
                bundle.obj.grade = 0
            return True
        raise Unauthorized("You are not allowed to access that resource.")

    def update_list(self, object_list, bundle):
        app_label = bundle.obj._meta.app_label
        model_name = bundle.obj._meta.model_name
        if bundle.request.user.has_perm('{}.change_{}'.format(app_label, model_name)):
            return object_list
        raise Unauthorized("You are not allowed to access that resource.")

    def update_detail(self, object_list, bundle):
        app_label = bundle.obj._meta.app_label
        model_name = bundle.obj._meta.model_name
        if bundle.request.user.has_perm('{}.change_{}'.format(app_label, model_name)):
            return True
        raise Unauthorized("You are not allowed to access that resource.")

    def delete_list(self, object_list, bundle):
        app_label = bundle.obj._meta.app_label
        model_name = bundle.obj._meta.model_name
        if bundle.request.user.has_perm('{}.delete_{}'.format(app_label, model_name)):
            return object_list
        raise Unauthorized("You are not allowed to access that resource.")

    def delete_detail(self, object_list, bundle):
        app_label = bundle.obj._meta.app_label
        model_name = bundle.obj._meta.model_name
        if bundle.request.user.has_perm('{}.delete_{}'.format(app_label, model_name)):
            return True
        raise Unauthorized("You are not allowed to access that resource.")
